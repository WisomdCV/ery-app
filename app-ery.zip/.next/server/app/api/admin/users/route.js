/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/admin/users/route";
exports.ids = ["app/api/admin/users/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fadmin%2Fusers%2Froute&page=%2Fapi%2Fadmin%2Fusers%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fusers%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fadmin%2Fusers%2Froute&page=%2Fapi%2Fadmin%2Fusers%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fusers%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var D_Constellations_Leo_ERYProject_ery_app_src_app_api_admin_users_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/admin/users/route.ts */ \"(rsc)/./src/app/api/admin/users/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/admin/users/route\",\n        pathname: \"/api/admin/users\",\n        filename: \"route\",\n        bundlePath: \"app/api/admin/users/route\"\n    },\n    resolvedPagePath: \"D:\\\\Constellations\\\\Leo\\\\ERYProject\\\\ery-app\\\\src\\\\app\\\\api\\\\admin\\\\users\\\\route.ts\",\n    nextConfigOutput,\n    userland: D_Constellations_Leo_ERYProject_ery_app_src_app_api_admin_users_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZhZG1pbiUyRnVzZXJzJTJGcm91dGUmcGFnZT0lMkZhcGklMkZhZG1pbiUyRnVzZXJzJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGYWRtaW4lMkZ1c2VycyUyRnJvdXRlLnRzJmFwcERpcj1EJTNBJTVDQ29uc3RlbGxhdGlvbnMlNUNMZW8lNUNFUllQcm9qZWN0JTVDZXJ5LWFwcCU1Q3NyYyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RCUzQSU1Q0NvbnN0ZWxsYXRpb25zJTVDTGVvJTVDRVJZUHJvamVjdCU1Q2VyeS1hcHAmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQ21DO0FBQ2hIO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJEOlxcXFxDb25zdGVsbGF0aW9uc1xcXFxMZW9cXFxcRVJZUHJvamVjdFxcXFxlcnktYXBwXFxcXHNyY1xcXFxhcHBcXFxcYXBpXFxcXGFkbWluXFxcXHVzZXJzXFxcXHJvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9hZG1pbi91c2Vycy9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2FkbWluL3VzZXJzXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9hZG1pbi91c2Vycy9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkQ6XFxcXENvbnN0ZWxsYXRpb25zXFxcXExlb1xcXFxFUllQcm9qZWN0XFxcXGVyeS1hcHBcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcYWRtaW5cXFxcdXNlcnNcXFxccm91dGUudHNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICB3b3JrQXN5bmNTdG9yYWdlLFxuICAgICAgICB3b3JrVW5pdEFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fadmin%2Fusers%2Froute&page=%2Fapi%2Fadmin%2Fusers%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fusers%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/admin/users/route.ts":
/*!******************************************!*\
  !*** ./src/app/api/admin/users/route.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _lib_apiAuthUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/apiAuthUtils */ \"(rsc)/./src/lib/apiAuthUtils.ts\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./src/lib/db.ts\");\n// src/app/api/admin/users/route.ts\n\n // Nuestra función de ayuda para autenticación/autorización\n // Nuestra utilidad de base de datos\nasync function GET(request) {\n    // Proteger esta ruta: solo para administradores\n    const { user: adminUser, errorResponse } = await (0,_lib_apiAuthUtils__WEBPACK_IMPORTED_MODULE_1__.verifyAuth)(request, [\n        'administrador'\n    ]);\n    if (errorResponse) {\n        return errorResponse; // Si hay error de autenticación/autorización, devolverlo\n    }\n    // Si llegamos aquí, el usuario está autenticado y tiene el rol 'administrador'\n    // adminUser contiene la información decodificada del token del administrador\n    console.log(`Administrador ${adminUser?.email} (ID: ${adminUser?.userId}) está solicitando la lista de usuarios.`);\n    try {\n        // Consultar todos los usuarios. Excluir el password_hash y otros datos sensibles.\n        // También podemos obtener los roles de cada usuario si es necesario con un JOIN.\n        // Por ahora, una lista simple de usuarios.\n        const users = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_2__.query)(`SELECT id, nombre, apellido, email, activo, fecha_creacion \n       FROM usuarios \n       ORDER BY fecha_creacion DESC` // Opcional: ordenar por fecha de creación o nombre\n        );\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            users\n        }, {\n            status: 200\n        });\n    } catch (error) {\n        const typedError = error;\n        console.error('Error al obtener la lista de usuarios para el administrador:', typedError);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            message: 'Error interno del servidor al obtener la lista de usuarios.',\n            errorDetails: typedError.message\n        }, {\n            status: 500\n        });\n    }\n} // Aquí podrías añadir una función POST para que un administrador cree usuarios,\n // pero la dejaremos para más adelante si es necesario.\n // export async function POST(request: NextRequest) {\n //   const { user: adminUser, errorResponse } = await verifyAuth(request, ['administrador']);\n //   if (errorResponse) {\n //     return errorResponse;\n //   }\n //   // ... lógica para crear un nuevo usuario por un administrador ...\n //   return NextResponse.json({ message: \"Usuario creado por administrador\" });\n // }\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9hZG1pbi91c2Vycy9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsbUNBQW1DO0FBQ3FCO0FBQ1IsQ0FBQywyREFBMkQ7QUFDM0UsQ0FBQyxvQ0FBb0M7QUFjL0QsZUFBZUcsSUFBSUMsT0FBb0I7SUFDNUMsZ0RBQWdEO0lBQ2hELE1BQU0sRUFBRUMsTUFBTUMsU0FBUyxFQUFFQyxhQUFhLEVBQUUsR0FBRyxNQUFNTiw2REFBVUEsQ0FBQ0csU0FBUztRQUFDO0tBQWdCO0lBRXRGLElBQUlHLGVBQWU7UUFDakIsT0FBT0EsZUFBZSx5REFBeUQ7SUFDakY7SUFFQSwrRUFBK0U7SUFDL0UsNkVBQTZFO0lBQzdFQyxRQUFRQyxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUVILFdBQVdJLE1BQU0sTUFBTSxFQUFFSixXQUFXSyxPQUFPLHdDQUF3QyxDQUFDO0lBRWpILElBQUk7UUFDRixrRkFBa0Y7UUFDbEYsaUZBQWlGO1FBQ2pGLDJDQUEyQztRQUMzQyxNQUFNQyxRQUFRLE1BQU1WLDhDQUFLQSxDQUN2QixDQUFDOzttQ0FFNEIsQ0FBQyxDQUFDLG1EQUFtRDs7UUFHcEYsT0FBT0YscURBQVlBLENBQUNhLElBQUksQ0FBQztZQUFFRDtRQUFNLEdBQUc7WUFBRUUsUUFBUTtRQUFJO0lBRXBELEVBQUUsT0FBT0MsT0FBTztRQUNkLE1BQU1DLGFBQWFEO1FBQ25CUCxRQUFRTyxLQUFLLENBQUMsZ0VBQWdFQztRQUM5RSxPQUFPaEIscURBQVlBLENBQUNhLElBQUksQ0FDdEI7WUFBRUksU0FBUztZQUErREMsY0FBY0YsV0FBV0MsT0FBTztRQUFDLEdBQzNHO1lBQUVILFFBQVE7UUFBSTtJQUVsQjtBQUNGLEVBRUEsZ0ZBQWdGO0NBQ2hGLHVEQUF1RDtDQUN2RCxxREFBcUQ7Q0FDckQsNkZBQTZGO0NBQzdGLHlCQUF5QjtDQUN6Qiw0QkFBNEI7Q0FDNUIsTUFBTTtDQUNOLHVFQUF1RTtDQUN2RSwrRUFBK0U7Q0FDL0UsSUFBSSIsInNvdXJjZXMiOlsiRDpcXENvbnN0ZWxsYXRpb25zXFxMZW9cXEVSWVByb2plY3RcXGVyeS1hcHBcXHNyY1xcYXBwXFxhcGlcXGFkbWluXFx1c2Vyc1xccm91dGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2FwcC9hcGkvYWRtaW4vdXNlcnMvcm91dGUudHNcclxuaW1wb3J0IHsgTmV4dFJlcXVlc3QsIE5leHRSZXNwb25zZSB9IGZyb20gJ25leHQvc2VydmVyJztcclxuaW1wb3J0IHsgdmVyaWZ5QXV0aCB9IGZyb20gJ0AvbGliL2FwaUF1dGhVdGlscyc7IC8vIE51ZXN0cmEgZnVuY2nDs24gZGUgYXl1ZGEgcGFyYSBhdXRlbnRpY2FjacOzbi9hdXRvcml6YWNpw7NuXHJcbmltcG9ydCB7IHF1ZXJ5IH0gZnJvbSAnQC9saWIvZGInOyAvLyBOdWVzdHJhIHV0aWxpZGFkIGRlIGJhc2UgZGUgZGF0b3NcclxuaW1wb3J0IHsgUm93RGF0YVBhY2tldCB9IGZyb20gJ215c3FsMic7XHJcblxyXG4vLyBJbnRlcmZheiBwYXJhIGxvcyBkYXRvcyBkZWwgdXN1YXJpbyBxdWUgZGV2b2x2ZXJlbW9zIChleGNsdXllbmRvIGRhdG9zIHNlbnNpYmxlcylcclxuaW50ZXJmYWNlIFVzZXJMaXN0RGF0YSBleHRlbmRzIFJvd0RhdGFQYWNrZXQge1xyXG4gIGlkOiBudW1iZXI7XHJcbiAgbm9tYnJlOiBzdHJpbmc7XHJcbiAgYXBlbGxpZG86IHN0cmluZyB8IG51bGw7XHJcbiAgZW1haWw6IHN0cmluZztcclxuICBhY3Rpdm86IGJvb2xlYW47XHJcbiAgZmVjaGFfY3JlYWNpb246IERhdGU7XHJcbiAgLy8gUG9kcsOtYW1vcyBhw7FhZGlyIGxvcyByb2xlcyBkZWwgdXN1YXJpbyBhcXXDrSB0YW1iacOpbiBzaSBlcyBuZWNlc2FyaW9cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVChyZXF1ZXN0OiBOZXh0UmVxdWVzdCkge1xyXG4gIC8vIFByb3RlZ2VyIGVzdGEgcnV0YTogc29sbyBwYXJhIGFkbWluaXN0cmFkb3Jlc1xyXG4gIGNvbnN0IHsgdXNlcjogYWRtaW5Vc2VyLCBlcnJvclJlc3BvbnNlIH0gPSBhd2FpdCB2ZXJpZnlBdXRoKHJlcXVlc3QsIFsnYWRtaW5pc3RyYWRvciddKTtcclxuXHJcbiAgaWYgKGVycm9yUmVzcG9uc2UpIHtcclxuICAgIHJldHVybiBlcnJvclJlc3BvbnNlOyAvLyBTaSBoYXkgZXJyb3IgZGUgYXV0ZW50aWNhY2nDs24vYXV0b3JpemFjacOzbiwgZGV2b2x2ZXJsb1xyXG4gIH1cclxuXHJcbiAgLy8gU2kgbGxlZ2Ftb3MgYXF1w60sIGVsIHVzdWFyaW8gZXN0w6EgYXV0ZW50aWNhZG8geSB0aWVuZSBlbCByb2wgJ2FkbWluaXN0cmFkb3InXHJcbiAgLy8gYWRtaW5Vc2VyIGNvbnRpZW5lIGxhIGluZm9ybWFjacOzbiBkZWNvZGlmaWNhZGEgZGVsIHRva2VuIGRlbCBhZG1pbmlzdHJhZG9yXHJcbiAgY29uc29sZS5sb2coYEFkbWluaXN0cmFkb3IgJHthZG1pblVzZXI/LmVtYWlsfSAoSUQ6ICR7YWRtaW5Vc2VyPy51c2VySWR9KSBlc3TDoSBzb2xpY2l0YW5kbyBsYSBsaXN0YSBkZSB1c3Vhcmlvcy5gKTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIC8vIENvbnN1bHRhciB0b2RvcyBsb3MgdXN1YXJpb3MuIEV4Y2x1aXIgZWwgcGFzc3dvcmRfaGFzaCB5IG90cm9zIGRhdG9zIHNlbnNpYmxlcy5cclxuICAgIC8vIFRhbWJpw6luIHBvZGVtb3Mgb2J0ZW5lciBsb3Mgcm9sZXMgZGUgY2FkYSB1c3VhcmlvIHNpIGVzIG5lY2VzYXJpbyBjb24gdW4gSk9JTi5cclxuICAgIC8vIFBvciBhaG9yYSwgdW5hIGxpc3RhIHNpbXBsZSBkZSB1c3Vhcmlvcy5cclxuICAgIGNvbnN0IHVzZXJzID0gYXdhaXQgcXVlcnk8VXNlckxpc3REYXRhW10+KFxyXG4gICAgICBgU0VMRUNUIGlkLCBub21icmUsIGFwZWxsaWRvLCBlbWFpbCwgYWN0aXZvLCBmZWNoYV9jcmVhY2lvbiBcclxuICAgICAgIEZST00gdXN1YXJpb3MgXHJcbiAgICAgICBPUkRFUiBCWSBmZWNoYV9jcmVhY2lvbiBERVNDYCAvLyBPcGNpb25hbDogb3JkZW5hciBwb3IgZmVjaGEgZGUgY3JlYWNpw7NuIG8gbm9tYnJlXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHVzZXJzIH0sIHsgc3RhdHVzOiAyMDAgfSk7XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zdCB0eXBlZEVycm9yID0gZXJyb3IgYXMgeyBtZXNzYWdlPzogc3RyaW5nOyBjb2RlPzogc3RyaW5nOyBzcWxTdGF0ZT86IHN0cmluZyB9O1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgb2J0ZW5lciBsYSBsaXN0YSBkZSB1c3VhcmlvcyBwYXJhIGVsIGFkbWluaXN0cmFkb3I6JywgdHlwZWRFcnJvcik7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oXHJcbiAgICAgIHsgbWVzc2FnZTogJ0Vycm9yIGludGVybm8gZGVsIHNlcnZpZG9yIGFsIG9idGVuZXIgbGEgbGlzdGEgZGUgdXN1YXJpb3MuJywgZXJyb3JEZXRhaWxzOiB0eXBlZEVycm9yLm1lc3NhZ2UgfSxcclxuICAgICAgeyBzdGF0dXM6IDUwMCB9XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8gQXF1w60gcG9kcsOtYXMgYcOxYWRpciB1bmEgZnVuY2nDs24gUE9TVCBwYXJhIHF1ZSB1biBhZG1pbmlzdHJhZG9yIGNyZWUgdXN1YXJpb3MsXHJcbi8vIHBlcm8gbGEgZGVqYXJlbW9zIHBhcmEgbcOhcyBhZGVsYW50ZSBzaSBlcyBuZWNlc2FyaW8uXHJcbi8vIGV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcXVlc3Q6IE5leHRSZXF1ZXN0KSB7XHJcbi8vICAgY29uc3QgeyB1c2VyOiBhZG1pblVzZXIsIGVycm9yUmVzcG9uc2UgfSA9IGF3YWl0IHZlcmlmeUF1dGgocmVxdWVzdCwgWydhZG1pbmlzdHJhZG9yJ10pO1xyXG4vLyAgIGlmIChlcnJvclJlc3BvbnNlKSB7XHJcbi8vICAgICByZXR1cm4gZXJyb3JSZXNwb25zZTtcclxuLy8gICB9XHJcbi8vICAgLy8gLi4uIGzDs2dpY2EgcGFyYSBjcmVhciB1biBudWV2byB1c3VhcmlvIHBvciB1biBhZG1pbmlzdHJhZG9yIC4uLlxyXG4vLyAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG1lc3NhZ2U6IFwiVXN1YXJpbyBjcmVhZG8gcG9yIGFkbWluaXN0cmFkb3JcIiB9KTtcclxuLy8gfVxyXG4iXSwibmFtZXMiOlsiTmV4dFJlc3BvbnNlIiwidmVyaWZ5QXV0aCIsInF1ZXJ5IiwiR0VUIiwicmVxdWVzdCIsInVzZXIiLCJhZG1pblVzZXIiLCJlcnJvclJlc3BvbnNlIiwiY29uc29sZSIsImxvZyIsImVtYWlsIiwidXNlcklkIiwidXNlcnMiLCJqc29uIiwic3RhdHVzIiwiZXJyb3IiLCJ0eXBlZEVycm9yIiwibWVzc2FnZSIsImVycm9yRGV0YWlscyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/admin/users/route.ts\n");

/***/ }),

/***/ "(rsc)/./src/lib/apiAuthUtils.ts":
/*!*********************************!*\
  !*** ./src/lib/apiAuthUtils.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   verifyAuth: () => (/* binding */ verifyAuth)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__);\n// src/lib/apiAuthUtils.ts\n\n\n/**\r\n * Verifica la autenticación y autorización de una solicitud API.\r\n * @param request La NextRequest entrante.\r\n * @param requiredRoles Un array opcional de roles requeridos para acceder al recurso.\r\n * Si se provee, el usuario debe tener al menos uno de estos roles.\r\n * Si se omite o es un array vacío, solo se verifica la autenticación.\r\n * @returns Un objeto AuthResult con el usuario decodificado o una respuesta de error.\r\n */ async function verifyAuth(request, requiredRoles = []) {\n    const authHeader = request.headers.get('Authorization');\n    if (!authHeader) {\n        return {\n            user: null,\n            errorResponse: next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Token de autorización no proporcionado.'\n            }, {\n                status: 401\n            })\n        };\n    }\n    const tokenParts = authHeader.split(' ');\n    if (tokenParts.length !== 2 || tokenParts[0].toLowerCase() !== 'bearer' || !tokenParts[1]) {\n        return {\n            user: null,\n            errorResponse: next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Formato de token inválido. Se esperaba \"Bearer <token>\".'\n            }, {\n                status: 401\n            })\n        };\n    }\n    const token = tokenParts[1];\n    const jwtSecret = process.env.JWT_SECRET;\n    if (!jwtSecret) {\n        console.error('JWT_SECRET no está definido en las variables de entorno.');\n        return {\n            user: null,\n            errorResponse: next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Error de configuración del servidor (JWT Secret).'\n            }, {\n                status: 500\n            })\n        };\n    }\n    try {\n        const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().verify(token, jwtSecret);\n        // Verificar si se requieren roles específicos\n        if (requiredRoles.length > 0) {\n            const userHasRequiredRole = decoded.roles && decoded.roles.some((userRole)=>requiredRoles.includes(userRole));\n            if (!userHasRequiredRole) {\n                return {\n                    user: null,\n                    errorResponse: next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                        message: `Acceso denegado. Se requiere uno de los siguientes roles: ${requiredRoles.join(', ')}.`\n                    }, {\n                        status: 403\n                    })\n                };\n            }\n        }\n        // Autenticación y autorización (si se requirió) exitosas\n        return {\n            user: decoded,\n            errorResponse: null\n        };\n    } catch (error) {\n        let errorMessage = 'Token inválido o expirado.';\n        let statusCode = 401; // No autorizado por token inválido\n        if (error instanceof (jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().TokenExpiredError)) {\n            errorMessage = 'El token ha expirado.';\n            statusCode = 401; // O 403 si prefieres para expirado\n        } else if (error instanceof (jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().JsonWebTokenError)) {\n            errorMessage = 'Token inválido.';\n        } else {\n            // Otros errores inesperados durante la verificación del token\n            console.error('Error inesperado al verificar el token:', error);\n            errorMessage = 'Error al procesar el token.';\n            statusCode = 500; // Error interno del servidor\n        }\n        return {\n            user: null,\n            errorResponse: next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: errorMessage\n            }, {\n                status: statusCode\n            })\n        };\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvbGliL2FwaUF1dGhVdGlscy50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsMEJBQTBCO0FBQzhCO0FBQ1Q7QUFjL0M7Ozs7Ozs7Q0FPQyxHQUNNLGVBQWVFLFdBQ3BCQyxPQUFvQixFQUNwQkMsZ0JBQTBCLEVBQUU7SUFFNUIsTUFBTUMsYUFBYUYsUUFBUUcsT0FBTyxDQUFDQyxHQUFHLENBQUM7SUFFdkMsSUFBSSxDQUFDRixZQUFZO1FBQ2YsT0FBTztZQUNMRyxNQUFNO1lBQ05DLGVBQWVULHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7Z0JBQUVDLFNBQVM7WUFBMEMsR0FBRztnQkFBRUMsUUFBUTtZQUFJO1FBQ3pHO0lBQ0Y7SUFFQSxNQUFNQyxhQUFhUixXQUFXUyxLQUFLLENBQUM7SUFDcEMsSUFBSUQsV0FBV0UsTUFBTSxLQUFLLEtBQUtGLFVBQVUsQ0FBQyxFQUFFLENBQUNHLFdBQVcsT0FBTyxZQUFZLENBQUNILFVBQVUsQ0FBQyxFQUFFLEVBQUU7UUFDekYsT0FBTztZQUNMTCxNQUFNO1lBQ05DLGVBQWVULHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7Z0JBQUVDLFNBQVM7WUFBMkQsR0FBRztnQkFBRUMsUUFBUTtZQUFJO1FBQzFIO0lBQ0Y7SUFFQSxNQUFNSyxRQUFRSixVQUFVLENBQUMsRUFBRTtJQUMzQixNQUFNSyxZQUFZQyxRQUFRQyxHQUFHLENBQUNDLFVBQVU7SUFFeEMsSUFBSSxDQUFDSCxXQUFXO1FBQ2RJLFFBQVFDLEtBQUssQ0FBQztRQUNkLE9BQU87WUFDTGYsTUFBTTtZQUNOQyxlQUFlVCxxREFBWUEsQ0FBQ1UsSUFBSSxDQUFDO2dCQUFFQyxTQUFTO1lBQW9ELEdBQUc7Z0JBQUVDLFFBQVE7WUFBSTtRQUNuSDtJQUNGO0lBRUEsSUFBSTtRQUNGLE1BQU1ZLFVBQVV2QiwwREFBVSxDQUFDZ0IsT0FBT0M7UUFFbEMsOENBQThDO1FBQzlDLElBQUlkLGNBQWNXLE1BQU0sR0FBRyxHQUFHO1lBQzVCLE1BQU1XLHNCQUFzQkYsUUFBUUcsS0FBSyxJQUFJSCxRQUFRRyxLQUFLLENBQUNDLElBQUksQ0FBQ0MsQ0FBQUEsV0FBWXpCLGNBQWMwQixRQUFRLENBQUNEO1lBQ25HLElBQUksQ0FBQ0gscUJBQXFCO2dCQUN4QixPQUFPO29CQUNMbEIsTUFBTTtvQkFDTkMsZUFBZVQscURBQVlBLENBQUNVLElBQUksQ0FDOUI7d0JBQUVDLFNBQVMsQ0FBQywwREFBMEQsRUFBRVAsY0FBYzJCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFBQyxHQUNwRzt3QkFBRW5CLFFBQVE7b0JBQUk7Z0JBRWxCO1lBQ0Y7UUFDRjtRQUVBLHlEQUF5RDtRQUN6RCxPQUFPO1lBQUVKLE1BQU1nQjtZQUFTZixlQUFlO1FBQUs7SUFFOUMsRUFBRSxPQUFPYyxPQUFPO1FBQ2QsSUFBSVMsZUFBZTtRQUNuQixJQUFJQyxhQUFhLEtBQUssbUNBQW1DO1FBRXpELElBQUlWLGlCQUFpQnRCLHVFQUFxQixFQUFFO1lBQzFDK0IsZUFBZTtZQUNmQyxhQUFhLEtBQUssbUNBQW1DO1FBQ3ZELE9BQU8sSUFBSVYsaUJBQWlCdEIsdUVBQXFCLEVBQUU7WUFDakQrQixlQUFlO1FBQ2pCLE9BQU87WUFDTCw4REFBOEQ7WUFDOURWLFFBQVFDLEtBQUssQ0FBQywyQ0FBMkNBO1lBQ3pEUyxlQUFlO1lBQ2ZDLGFBQWEsS0FBSyw2QkFBNkI7UUFDakQ7UUFDQSxPQUFPO1lBQUV6QixNQUFNO1lBQU1DLGVBQWVULHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7Z0JBQUVDLFNBQVNxQjtZQUFhLEdBQUc7Z0JBQUVwQixRQUFRcUI7WUFBVztRQUFHO0lBQzNHO0FBQ0YiLCJzb3VyY2VzIjpbIkQ6XFxDb25zdGVsbGF0aW9uc1xcTGVvXFxFUllQcm9qZWN0XFxlcnktYXBwXFxzcmNcXGxpYlxcYXBpQXV0aFV0aWxzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9saWIvYXBpQXV0aFV0aWxzLnRzXHJcbmltcG9ydCB7IE5leHRSZXF1ZXN0LCBOZXh0UmVzcG9uc2UgfSBmcm9tICduZXh0L3NlcnZlcic7XHJcbmltcG9ydCBqd3QsIHsgSnd0UGF5bG9hZCB9IGZyb20gJ2pzb253ZWJ0b2tlbic7XHJcblxyXG5pbnRlcmZhY2UgRGVjb2RlZFRva2VuIGV4dGVuZHMgSnd0UGF5bG9hZCB7XHJcbiAgdXNlcklkOiBudW1iZXI7XHJcbiAgZW1haWw6IHN0cmluZztcclxuICBub21icmU6IHN0cmluZztcclxuICByb2xlczogc3RyaW5nW107XHJcbn1cclxuXHJcbmludGVyZmFjZSBBdXRoUmVzdWx0IHtcclxuICB1c2VyOiBEZWNvZGVkVG9rZW4gfCBudWxsO1xyXG4gIGVycm9yUmVzcG9uc2U6IE5leHRSZXNwb25zZSB8IG51bGw7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBWZXJpZmljYSBsYSBhdXRlbnRpY2FjacOzbiB5IGF1dG9yaXphY2nDs24gZGUgdW5hIHNvbGljaXR1ZCBBUEkuXHJcbiAqIEBwYXJhbSByZXF1ZXN0IExhIE5leHRSZXF1ZXN0IGVudHJhbnRlLlxyXG4gKiBAcGFyYW0gcmVxdWlyZWRSb2xlcyBVbiBhcnJheSBvcGNpb25hbCBkZSByb2xlcyByZXF1ZXJpZG9zIHBhcmEgYWNjZWRlciBhbCByZWN1cnNvLlxyXG4gKiBTaSBzZSBwcm92ZWUsIGVsIHVzdWFyaW8gZGViZSB0ZW5lciBhbCBtZW5vcyB1bm8gZGUgZXN0b3Mgcm9sZXMuXHJcbiAqIFNpIHNlIG9taXRlIG8gZXMgdW4gYXJyYXkgdmFjw61vLCBzb2xvIHNlIHZlcmlmaWNhIGxhIGF1dGVudGljYWNpw7NuLlxyXG4gKiBAcmV0dXJucyBVbiBvYmpldG8gQXV0aFJlc3VsdCBjb24gZWwgdXN1YXJpbyBkZWNvZGlmaWNhZG8gbyB1bmEgcmVzcHVlc3RhIGRlIGVycm9yLlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZlcmlmeUF1dGgoXHJcbiAgcmVxdWVzdDogTmV4dFJlcXVlc3QsXHJcbiAgcmVxdWlyZWRSb2xlczogc3RyaW5nW10gPSBbXVxyXG4pOiBQcm9taXNlPEF1dGhSZXN1bHQ+IHtcclxuICBjb25zdCBhdXRoSGVhZGVyID0gcmVxdWVzdC5oZWFkZXJzLmdldCgnQXV0aG9yaXphdGlvbicpO1xyXG5cclxuICBpZiAoIWF1dGhIZWFkZXIpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHVzZXI6IG51bGwsXHJcbiAgICAgIGVycm9yUmVzcG9uc2U6IE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogJ1Rva2VuIGRlIGF1dG9yaXphY2nDs24gbm8gcHJvcG9yY2lvbmFkby4nIH0sIHsgc3RhdHVzOiA0MDEgfSksXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdG9rZW5QYXJ0cyA9IGF1dGhIZWFkZXIuc3BsaXQoJyAnKTtcclxuICBpZiAodG9rZW5QYXJ0cy5sZW5ndGggIT09IDIgfHwgdG9rZW5QYXJ0c1swXS50b0xvd2VyQ2FzZSgpICE9PSAnYmVhcmVyJyB8fCAhdG9rZW5QYXJ0c1sxXSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdXNlcjogbnVsbCxcclxuICAgICAgZXJyb3JSZXNwb25zZTogTmV4dFJlc3BvbnNlLmpzb24oeyBtZXNzYWdlOiAnRm9ybWF0byBkZSB0b2tlbiBpbnbDoWxpZG8uIFNlIGVzcGVyYWJhIFwiQmVhcmVyIDx0b2tlbj5cIi4nIH0sIHsgc3RhdHVzOiA0MDEgfSksXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdG9rZW4gPSB0b2tlblBhcnRzWzFdO1xyXG4gIGNvbnN0IGp3dFNlY3JldCA9IHByb2Nlc3MuZW52LkpXVF9TRUNSRVQ7XHJcblxyXG4gIGlmICghand0U2VjcmV0KSB7XHJcbiAgICBjb25zb2xlLmVycm9yKCdKV1RfU0VDUkVUIG5vIGVzdMOhIGRlZmluaWRvIGVuIGxhcyB2YXJpYWJsZXMgZGUgZW50b3Juby4nKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHVzZXI6IG51bGwsXHJcbiAgICAgIGVycm9yUmVzcG9uc2U6IE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogJ0Vycm9yIGRlIGNvbmZpZ3VyYWNpw7NuIGRlbCBzZXJ2aWRvciAoSldUIFNlY3JldCkuJyB9LCB7IHN0YXR1czogNTAwIH0pLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkZWNvZGVkID0gand0LnZlcmlmeSh0b2tlbiwgand0U2VjcmV0KSBhcyBEZWNvZGVkVG9rZW47XHJcblxyXG4gICAgLy8gVmVyaWZpY2FyIHNpIHNlIHJlcXVpZXJlbiByb2xlcyBlc3BlY8OtZmljb3NcclxuICAgIGlmIChyZXF1aXJlZFJvbGVzLmxlbmd0aCA+IDApIHtcclxuICAgICAgY29uc3QgdXNlckhhc1JlcXVpcmVkUm9sZSA9IGRlY29kZWQucm9sZXMgJiYgZGVjb2RlZC5yb2xlcy5zb21lKHVzZXJSb2xlID0+IHJlcXVpcmVkUm9sZXMuaW5jbHVkZXModXNlclJvbGUpKTtcclxuICAgICAgaWYgKCF1c2VySGFzUmVxdWlyZWRSb2xlKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHVzZXI6IG51bGwsXHJcbiAgICAgICAgICBlcnJvclJlc3BvbnNlOiBOZXh0UmVzcG9uc2UuanNvbihcclxuICAgICAgICAgICAgeyBtZXNzYWdlOiBgQWNjZXNvIGRlbmVnYWRvLiBTZSByZXF1aWVyZSB1bm8gZGUgbG9zIHNpZ3VpZW50ZXMgcm9sZXM6ICR7cmVxdWlyZWRSb2xlcy5qb2luKCcsICcpfS5gIH0sXHJcbiAgICAgICAgICAgIHsgc3RhdHVzOiA0MDMgfVxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQXV0ZW50aWNhY2nDs24geSBhdXRvcml6YWNpw7NuIChzaSBzZSByZXF1aXJpw7MpIGV4aXRvc2FzXHJcbiAgICByZXR1cm4geyB1c2VyOiBkZWNvZGVkLCBlcnJvclJlc3BvbnNlOiBudWxsIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsZXQgZXJyb3JNZXNzYWdlID0gJ1Rva2VuIGludsOhbGlkbyBvIGV4cGlyYWRvLic7XHJcbiAgICBsZXQgc3RhdHVzQ29kZSA9IDQwMTsgLy8gTm8gYXV0b3JpemFkbyBwb3IgdG9rZW4gaW52w6FsaWRvXHJcblxyXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2Ygand0LlRva2VuRXhwaXJlZEVycm9yKSB7XHJcbiAgICAgIGVycm9yTWVzc2FnZSA9ICdFbCB0b2tlbiBoYSBleHBpcmFkby4nO1xyXG4gICAgICBzdGF0dXNDb2RlID0gNDAxOyAvLyBPIDQwMyBzaSBwcmVmaWVyZXMgcGFyYSBleHBpcmFkb1xyXG4gICAgfSBlbHNlIGlmIChlcnJvciBpbnN0YW5jZW9mIGp3dC5Kc29uV2ViVG9rZW5FcnJvcikge1xyXG4gICAgICBlcnJvck1lc3NhZ2UgPSAnVG9rZW4gaW52w6FsaWRvLic7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBPdHJvcyBlcnJvcmVzIGluZXNwZXJhZG9zIGR1cmFudGUgbGEgdmVyaWZpY2FjacOzbiBkZWwgdG9rZW5cclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW5lc3BlcmFkbyBhbCB2ZXJpZmljYXIgZWwgdG9rZW46JywgZXJyb3IpO1xyXG4gICAgICBlcnJvck1lc3NhZ2UgPSAnRXJyb3IgYWwgcHJvY2VzYXIgZWwgdG9rZW4uJztcclxuICAgICAgc3RhdHVzQ29kZSA9IDUwMDsgLy8gRXJyb3IgaW50ZXJubyBkZWwgc2Vydmlkb3JcclxuICAgIH1cclxuICAgIHJldHVybiB7IHVzZXI6IG51bGwsIGVycm9yUmVzcG9uc2U6IE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogZXJyb3JNZXNzYWdlIH0sIHsgc3RhdHVzOiBzdGF0dXNDb2RlIH0pIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJqd3QiLCJ2ZXJpZnlBdXRoIiwicmVxdWVzdCIsInJlcXVpcmVkUm9sZXMiLCJhdXRoSGVhZGVyIiwiaGVhZGVycyIsImdldCIsInVzZXIiLCJlcnJvclJlc3BvbnNlIiwianNvbiIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJ0b2tlblBhcnRzIiwic3BsaXQiLCJsZW5ndGgiLCJ0b0xvd2VyQ2FzZSIsInRva2VuIiwiand0U2VjcmV0IiwicHJvY2VzcyIsImVudiIsIkpXVF9TRUNSRVQiLCJjb25zb2xlIiwiZXJyb3IiLCJkZWNvZGVkIiwidmVyaWZ5IiwidXNlckhhc1JlcXVpcmVkUm9sZSIsInJvbGVzIiwic29tZSIsInVzZXJSb2xlIiwiaW5jbHVkZXMiLCJqb2luIiwiZXJyb3JNZXNzYWdlIiwic3RhdHVzQ29kZSIsIlRva2VuRXhwaXJlZEVycm9yIiwiSnNvbldlYlRva2VuRXJyb3IiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./src/lib/apiAuthUtils.ts\n");

/***/ }),

/***/ "(rsc)/./src/lib/db.ts":
/*!***********************!*\
  !*** ./src/lib/db.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   query: () => (/* binding */ query)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n// src/lib/db.ts\n\n// Configura los detalles de la conexión usando variables de entorno\nconst dbConfig = {\n    host: process.env.DB_HOST,\n    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306,\n    user: process.env.DB_USER,\n    password: process.env.DB_PASSWORD,\n    database: process.env.DB_NAME,\n    waitForConnections: true,\n    connectionLimit: 10,\n    queueLimit: 0\n};\n// El pool se crea una sola vez y se reutiliza\nlet pool;\nfunction getPool() {\n    if (!pool) {\n        try {\n            pool = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool(dbConfig);\n            console.log('MySQL Connection Pool created successfully.');\n        // Nota: mysql2/promise Pool no soporta el evento 'error' directamente en el pool object como en `mysql`.\n        // Los errores de conexión individuales se manejan en los catch de las consultas.\n        } catch (error) {\n            console.error('Failed to create MySQL Connection Pool:', error);\n            throw error;\n        }\n    }\n    return pool;\n}\n// Hacemos la función query más genérica con tipos\nasync function query(sql, // Corregido: params puede ser un array de primitivas o un objeto para sentencias preparadas\nparams) {\n    const currentPool = getPool();\n    // Corregido: La variable 'connection' no se usaba y ha sido eliminada.\n    try {\n        const [results] = await currentPool.execute(sql, params);\n        return results;\n    } catch (error) {\n        // Para el log, podemos acceder a 'message' y 'code' si asumimos que es un error de MySQL o similar.\n        // Para mayor seguridad, se podría hacer una verificación de tipo: if (error instanceof Error)\n        const typedError = error;\n        console.error('Error executing query:', {\n            sql,\n            params,\n            errorMessage: typedError.message,\n            errorCode: typedError.code,\n            sqlState: typedError.sqlState\n        });\n        throw new Error(`Database query failed. SQLState: ${typedError.sqlState}, Code: ${typedError.code}`);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvbGliL2RiLnRzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsZ0JBQWdCO0FBQ3VFO0FBZXZGLG9FQUFvRTtBQUNwRSxNQUFNQyxXQUFxQjtJQUN6QkMsTUFBTUMsUUFBUUMsR0FBRyxDQUFDQyxPQUFPO0lBQ3pCQyxNQUFNSCxRQUFRQyxHQUFHLENBQUNHLE9BQU8sR0FBR0MsU0FBU0wsUUFBUUMsR0FBRyxDQUFDRyxPQUFPLEVBQUUsTUFBTTtJQUNoRUUsTUFBTU4sUUFBUUMsR0FBRyxDQUFDTSxPQUFPO0lBQ3pCQyxVQUFVUixRQUFRQyxHQUFHLENBQUNRLFdBQVc7SUFDakNDLFVBQVVWLFFBQVFDLEdBQUcsQ0FBQ1UsT0FBTztJQUM3QkMsb0JBQW9CO0lBQ3BCQyxpQkFBaUI7SUFDakJDLFlBQVk7QUFDZDtBQUVBLDhDQUE4QztBQUM5QyxJQUFJQztBQUVKLFNBQVNDO0lBQ1AsSUFBSSxDQUFDRCxNQUFNO1FBQ1QsSUFBSTtZQUNGQSxPQUFPbEIsc0RBQWdCLENBQUNDO1lBQ3hCb0IsUUFBUUMsR0FBRyxDQUFDO1FBRVoseUdBQXlHO1FBQ3pHLGlGQUFpRjtRQUNuRixFQUFFLE9BQU9DLE9BQU87WUFDZEYsUUFBUUUsS0FBSyxDQUFDLDJDQUEyQ0E7WUFDekQsTUFBTUE7UUFDUjtJQUNGO0lBQ0EsT0FBT0w7QUFDVDtBQUVBLGtEQUFrRDtBQUMzQyxlQUFlTSxNQUNwQkMsR0FBVyxFQUNYLDRGQUE0RjtBQUM1RkMsTUFBbUY7SUFFbkYsTUFBTUMsY0FBY1I7SUFDcEIsdUVBQXVFO0lBQ3ZFLElBQUk7UUFDRixNQUFNLENBQUNTLFFBQVEsR0FBRyxNQUFNRCxZQUFZRSxPQUFPLENBQUlKLEtBQUtDO1FBQ3BELE9BQU9FO0lBQ1QsRUFBRSxPQUFPTCxPQUFPO1FBQ2Qsb0dBQW9HO1FBQ3BHLDhGQUE4RjtRQUM5RixNQUFNTyxhQUFhUDtRQUNuQkYsUUFBUUUsS0FBSyxDQUFDLDBCQUEwQjtZQUNwQ0U7WUFDQUM7WUFDQUssY0FBY0QsV0FBV0UsT0FBTztZQUNoQ0MsV0FBV0gsV0FBV0ksSUFBSTtZQUMxQkMsVUFBVUwsV0FBV0ssUUFBUTtRQUNqQztRQUNBLE1BQU0sSUFBSUMsTUFBTSxDQUFDLGlDQUFpQyxFQUFFTixXQUFXSyxRQUFRLENBQUMsUUFBUSxFQUFFTCxXQUFXSSxJQUFJLEVBQUU7SUFDckc7QUFDRiIsInNvdXJjZXMiOlsiRDpcXENvbnN0ZWxsYXRpb25zXFxMZW9cXEVSWVByb2plY3RcXGVyeS1hcHBcXHNyY1xcbGliXFxkYi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvbGliL2RiLnRzXHJcbmltcG9ydCBteXNxbCwgeyBQb29sLCBSb3dEYXRhUGFja2V0LCBPa1BhY2tldCwgUmVzdWx0U2V0SGVhZGVyIH0gZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuLy8gRGVmaW5pbW9zIHVuYSBpbnRlcmZheiBwYXJhIGxhIGNvbmZpZ3VyYWNpw7NuIGRlIGxhIEJEIHBhcmEgbWF5b3IgY2xhcmlkYWRcclxuaW50ZXJmYWNlIERiQ29uZmlnIHtcclxuICBob3N0Pzogc3RyaW5nO1xyXG4gIHBvcnQ/OiBudW1iZXI7XHJcbiAgdXNlcj86IHN0cmluZztcclxuICBwYXNzd29yZD86IHN0cmluZztcclxuICBkYXRhYmFzZT86IHN0cmluZztcclxuICAvLyBPcGNpb25lcyBhZGljaW9uYWxlcyBwYXJhIGVsIHBvb2wgc2kgbGFzIG5lY2VzaXRhc1xyXG4gIHdhaXRGb3JDb25uZWN0aW9ucz86IGJvb2xlYW47XHJcbiAgY29ubmVjdGlvbkxpbWl0PzogbnVtYmVyO1xyXG4gIHF1ZXVlTGltaXQ/OiBudW1iZXI7XHJcbn1cclxuXHJcbi8vIENvbmZpZ3VyYSBsb3MgZGV0YWxsZXMgZGUgbGEgY29uZXhpw7NuIHVzYW5kbyB2YXJpYWJsZXMgZGUgZW50b3Jub1xyXG5jb25zdCBkYkNvbmZpZzogRGJDb25maWcgPSB7XHJcbiAgaG9zdDogcHJvY2Vzcy5lbnYuREJfSE9TVCxcclxuICBwb3J0OiBwcm9jZXNzLmVudi5EQl9QT1JUID8gcGFyc2VJbnQocHJvY2Vzcy5lbnYuREJfUE9SVCwgMTApIDogMzMwNixcclxuICB1c2VyOiBwcm9jZXNzLmVudi5EQl9VU0VSLFxyXG4gIHBhc3N3b3JkOiBwcm9jZXNzLmVudi5EQl9QQVNTV09SRCxcclxuICBkYXRhYmFzZTogcHJvY2Vzcy5lbnYuREJfTkFNRSxcclxuICB3YWl0Rm9yQ29ubmVjdGlvbnM6IHRydWUsXHJcbiAgY29ubmVjdGlvbkxpbWl0OiAxMCwgLy8gUHVlZGVzIGFqdXN0YXIgZXN0ZSB2YWxvciBzZWfDum4gdHVzIG5lY2VzaWRhZGVzXHJcbiAgcXVldWVMaW1pdDogMFxyXG59O1xyXG5cclxuLy8gRWwgcG9vbCBzZSBjcmVhIHVuYSBzb2xhIHZleiB5IHNlIHJldXRpbGl6YVxyXG5sZXQgcG9vbDogUG9vbCB8IHVuZGVmaW5lZDtcclxuXHJcbmZ1bmN0aW9uIGdldFBvb2woKTogUG9vbCB7XHJcbiAgaWYgKCFwb29sKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBwb29sID0gbXlzcWwuY3JlYXRlUG9vbChkYkNvbmZpZyk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdNeVNRTCBDb25uZWN0aW9uIFBvb2wgY3JlYXRlZCBzdWNjZXNzZnVsbHkuJyk7XHJcblxyXG4gICAgICAvLyBOb3RhOiBteXNxbDIvcHJvbWlzZSBQb29sIG5vIHNvcG9ydGEgZWwgZXZlbnRvICdlcnJvcicgZGlyZWN0YW1lbnRlIGVuIGVsIHBvb2wgb2JqZWN0IGNvbW8gZW4gYG15c3FsYC5cclxuICAgICAgLy8gTG9zIGVycm9yZXMgZGUgY29uZXhpw7NuIGluZGl2aWR1YWxlcyBzZSBtYW5lamFuIGVuIGxvcyBjYXRjaCBkZSBsYXMgY29uc3VsdGFzLlxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGNyZWF0ZSBNeVNRTCBDb25uZWN0aW9uIFBvb2w6JywgZXJyb3IpO1xyXG4gICAgICB0aHJvdyBlcnJvcjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHBvb2w7XHJcbn1cclxuXHJcbi8vIEhhY2Vtb3MgbGEgZnVuY2nDs24gcXVlcnkgbcOhcyBnZW7DqXJpY2EgY29uIHRpcG9zXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWVyeTxUIGV4dGVuZHMgUm93RGF0YVBhY2tldFtdIHwgUm93RGF0YVBhY2tldFtdW10gfCBPa1BhY2tldCB8IE9rUGFja2V0W10gfCBSZXN1bHRTZXRIZWFkZXI+KFxyXG4gIHNxbDogc3RyaW5nLFxyXG4gIC8vIENvcnJlZ2lkbzogcGFyYW1zIHB1ZWRlIHNlciB1biBhcnJheSBkZSBwcmltaXRpdmFzIG8gdW4gb2JqZXRvIHBhcmEgc2VudGVuY2lhcyBwcmVwYXJhZGFzXHJcbiAgcGFyYW1zPzogKHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBudWxsKVtdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCB1bmRlZmluZWRcclxuKTogUHJvbWlzZTxUPiB7XHJcbiAgY29uc3QgY3VycmVudFBvb2wgPSBnZXRQb29sKCk7XHJcbiAgLy8gQ29ycmVnaWRvOiBMYSB2YXJpYWJsZSAnY29ubmVjdGlvbicgbm8gc2UgdXNhYmEgeSBoYSBzaWRvIGVsaW1pbmFkYS5cclxuICB0cnkge1xyXG4gICAgY29uc3QgW3Jlc3VsdHNdID0gYXdhaXQgY3VycmVudFBvb2wuZXhlY3V0ZTxUPihzcWwsIHBhcmFtcyk7XHJcbiAgICByZXR1cm4gcmVzdWx0cztcclxuICB9IGNhdGNoIChlcnJvcikgeyAvLyBDb3JyZWdpZG86IFVzYXIgJ3Vua25vd24nIHBhcmEgZWwgdGlwbyBkZSBlcnJvciB5IGx1ZWdvIHZlcmlmaWNhcmxvIHNpIGVzIG5lY2VzYXJpb1xyXG4gICAgLy8gUGFyYSBlbCBsb2csIHBvZGVtb3MgYWNjZWRlciBhICdtZXNzYWdlJyB5ICdjb2RlJyBzaSBhc3VtaW1vcyBxdWUgZXMgdW4gZXJyb3IgZGUgTXlTUUwgbyBzaW1pbGFyLlxyXG4gICAgLy8gUGFyYSBtYXlvciBzZWd1cmlkYWQsIHNlIHBvZHLDrWEgaGFjZXIgdW5hIHZlcmlmaWNhY2nDs24gZGUgdGlwbzogaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpXHJcbiAgICBjb25zdCB0eXBlZEVycm9yID0gZXJyb3IgYXMgeyBtZXNzYWdlPzogc3RyaW5nOyBjb2RlPzogc3RyaW5nOyBzcWxTdGF0ZT86IHN0cmluZyB9O1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgZXhlY3V0aW5nIHF1ZXJ5OicsIHtcclxuICAgICAgICBzcWwsXHJcbiAgICAgICAgcGFyYW1zLFxyXG4gICAgICAgIGVycm9yTWVzc2FnZTogdHlwZWRFcnJvci5tZXNzYWdlLFxyXG4gICAgICAgIGVycm9yQ29kZTogdHlwZWRFcnJvci5jb2RlLFxyXG4gICAgICAgIHNxbFN0YXRlOiB0eXBlZEVycm9yLnNxbFN0YXRlXHJcbiAgICB9KTtcclxuICAgIHRocm93IG5ldyBFcnJvcihgRGF0YWJhc2UgcXVlcnkgZmFpbGVkLiBTUUxTdGF0ZTogJHt0eXBlZEVycm9yLnNxbFN0YXRlfSwgQ29kZTogJHt0eXBlZEVycm9yLmNvZGV9YCk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJteXNxbCIsImRiQ29uZmlnIiwiaG9zdCIsInByb2Nlc3MiLCJlbnYiLCJEQl9IT1NUIiwicG9ydCIsIkRCX1BPUlQiLCJwYXJzZUludCIsInVzZXIiLCJEQl9VU0VSIiwicGFzc3dvcmQiLCJEQl9QQVNTV09SRCIsImRhdGFiYXNlIiwiREJfTkFNRSIsIndhaXRGb3JDb25uZWN0aW9ucyIsImNvbm5lY3Rpb25MaW1pdCIsInF1ZXVlTGltaXQiLCJwb29sIiwiZ2V0UG9vbCIsImNyZWF0ZVBvb2wiLCJjb25zb2xlIiwibG9nIiwiZXJyb3IiLCJxdWVyeSIsInNxbCIsInBhcmFtcyIsImN1cnJlbnRQb29sIiwicmVzdWx0cyIsImV4ZWN1dGUiLCJ0eXBlZEVycm9yIiwiZXJyb3JNZXNzYWdlIiwibWVzc2FnZSIsImVycm9yQ29kZSIsImNvZGUiLCJzcWxTdGF0ZSIsIkVycm9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/lib/db.ts\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mysql2","vendor-chunks/aws-ssl-profiles","vendor-chunks/iconv-lite","vendor-chunks/semver","vendor-chunks/long","vendor-chunks/lru-cache","vendor-chunks/jsonwebtoken","vendor-chunks/lodash.includes","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/lru.min","vendor-chunks/jws","vendor-chunks/lodash.once","vendor-chunks/jwa","vendor-chunks/lodash.isinteger","vendor-chunks/sqlstring","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/seq-queue","vendor-chunks/named-placeholders","vendor-chunks/lodash.isplainobject","vendor-chunks/generate-function","vendor-chunks/ms","vendor-chunks/lodash.isstring","vendor-chunks/safer-buffer","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isboolean","vendor-chunks/safe-buffer","vendor-chunks/buffer-equal-constant-time"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fadmin%2Fusers%2Froute&page=%2Fapi%2Fadmin%2Fusers%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fusers%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();