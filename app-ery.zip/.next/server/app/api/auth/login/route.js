/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/auth/login/route";
exports.ids = ["app/api/auth/login/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fauth%2Flogin%2Froute&page=%2Fapi%2Fauth%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2Flogin%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fauth%2Flogin%2Froute&page=%2Fapi%2Fauth%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2Flogin%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var D_Constellations_Leo_ERYProject_ery_app_src_app_api_auth_login_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/auth/login/route.ts */ \"(rsc)/./src/app/api/auth/login/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/auth/login/route\",\n        pathname: \"/api/auth/login\",\n        filename: \"route\",\n        bundlePath: \"app/api/auth/login/route\"\n    },\n    resolvedPagePath: \"D:\\\\Constellations\\\\Leo\\\\ERYProject\\\\ery-app\\\\src\\\\app\\\\api\\\\auth\\\\login\\\\route.ts\",\n    nextConfigOutput,\n    userland: D_Constellations_Leo_ERYProject_ery_app_src_app_api_auth_login_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZhdXRoJTJGbG9naW4lMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRmF1dGglMkZsb2dpbiUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRmF1dGglMkZsb2dpbiUyRnJvdXRlLnRzJmFwcERpcj1EJTNBJTVDQ29uc3RlbGxhdGlvbnMlNUNMZW8lNUNFUllQcm9qZWN0JTVDZXJ5LWFwcCU1Q3NyYyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RCUzQSU1Q0NvbnN0ZWxsYXRpb25zJTVDTGVvJTVDRVJZUHJvamVjdCU1Q2VyeS1hcHAmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQ2tDO0FBQy9HO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJEOlxcXFxDb25zdGVsbGF0aW9uc1xcXFxMZW9cXFxcRVJZUHJvamVjdFxcXFxlcnktYXBwXFxcXHNyY1xcXFxhcHBcXFxcYXBpXFxcXGF1dGhcXFxcbG9naW5cXFxccm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2F1dGgvbG9naW4vcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9hdXRoL2xvZ2luXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9hdXRoL2xvZ2luL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiRDpcXFxcQ29uc3RlbGxhdGlvbnNcXFxcTGVvXFxcXEVSWVByb2plY3RcXFxcZXJ5LWFwcFxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxhdXRoXFxcXGxvZ2luXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fauth%2Flogin%2Froute&page=%2Fapi%2Fauth%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2Flogin%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/auth/login/route.ts":
/*!*****************************************!*\
  !*** ./src/app/api/auth/login/route.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./src/lib/db.ts\");\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bcryptjs */ \"(rsc)/./node_modules/bcryptjs/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);\n// src/app/api/auth/login/route.ts\n\n\n\n\nasync function POST(request) {\n    try {\n        const body = await request.json();\n        const { email, password } = body;\n        if (!email || !password) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Email y contraseña son requeridos.'\n            }, {\n                status: 400\n            });\n        }\n        const userResults = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__.query)('SELECT id, email, nombre, password_hash, activo FROM usuarios WHERE email = ?', [\n            email\n        ]);\n        if (userResults.length === 0) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Credenciales inválidas. Usuario no encontrado.'\n            }, {\n                status: 401\n            });\n        }\n        const user = userResults[0];\n        if (!user.activo) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Esta cuenta ha sido desactivada.'\n            }, {\n                status: 403\n            });\n        }\n        const isPasswordMatch = await bcryptjs__WEBPACK_IMPORTED_MODULE_2__[\"default\"].compare(password, user.password_hash);\n        if (!isPasswordMatch) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Credenciales inválidas. Contraseña incorrecta.'\n            }, {\n                status: 401\n            });\n        }\n        // Obtener los roles del usuario\n        const rolesResults = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__.query)(`SELECT r.nombre_rol\n       FROM roles r\n       JOIN usuario_roles ur ON r.id = ur.rol_id\n       WHERE ur.usuario_id = ?`, [\n            user.id\n        ]);\n        const roles = rolesResults.map((role)=>role.nombre_rol);\n        // Si las credenciales son correctas, generar un JWT\n        const jwtSecret = process.env.JWT_SECRET;\n        if (!jwtSecret) {\n            console.error('JWT_SECRET no está definido en las variables de entorno.');\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: 'Error de configuración del servidor.'\n            }, {\n                status: 500\n            });\n        }\n        const tokenPayload = {\n            userId: user.id,\n            email: user.email,\n            nombre: user.nombre,\n            roles: roles\n        };\n        const token = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().sign(tokenPayload, jwtSecret, {\n            expiresIn: '1h'\n        });\n        const response = next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            message: 'Inicio de sesión exitoso.',\n            user: {\n                id: user.id,\n                email: user.email,\n                nombre: user.nombre,\n                roles: roles\n            },\n            token\n        }, {\n            status: 200\n        });\n        return response;\n    } catch (error) {\n        const typedError = error;\n        console.error('Error en /api/auth/login:', typedError);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            message: 'Error interno del servidor.',\n            errorDetails: typedError.message\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9hdXRoL2xvZ2luL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLGtDQUFrQztBQUNzQjtBQUN2QjtBQUNIO0FBQ0M7QUF1QnhCLGVBQWVJLEtBQUtDLE9BQW9CO0lBQzdDLElBQUk7UUFDRixNQUFNQyxPQUFPLE1BQU1ELFFBQVFFLElBQUk7UUFDL0IsTUFBTSxFQUFFQyxLQUFLLEVBQUVDLFFBQVEsRUFBRSxHQUFHSDtRQUU1QixJQUFJLENBQUNFLFNBQVMsQ0FBQ0MsVUFBVTtZQUN2QixPQUFPVCxxREFBWUEsQ0FBQ08sSUFBSSxDQUFDO2dCQUFFRyxTQUFTO1lBQXFDLEdBQUc7Z0JBQUVDLFFBQVE7WUFBSTtRQUM1RjtRQUVBLE1BQU1DLGNBQWMsTUFBTVgsOENBQUtBLENBQzdCLGlGQUNBO1lBQUNPO1NBQU07UUFHVCxJQUFJSSxZQUFZQyxNQUFNLEtBQUssR0FBRztZQUM1QixPQUFPYixxREFBWUEsQ0FBQ08sSUFBSSxDQUFDO2dCQUFFRyxTQUFTO1lBQWlELEdBQUc7Z0JBQUVDLFFBQVE7WUFBSTtRQUN4RztRQUVBLE1BQU1HLE9BQU9GLFdBQVcsQ0FBQyxFQUFFO1FBRTNCLElBQUksQ0FBQ0UsS0FBS0MsTUFBTSxFQUFFO1lBQ2QsT0FBT2YscURBQVlBLENBQUNPLElBQUksQ0FBQztnQkFBRUcsU0FBUztZQUFtQyxHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDNUY7UUFFQSxNQUFNSyxrQkFBa0IsTUFBTWQsd0RBQWMsQ0FBQ08sVUFBVUssS0FBS0ksYUFBYTtRQUV6RSxJQUFJLENBQUNGLGlCQUFpQjtZQUNwQixPQUFPaEIscURBQVlBLENBQUNPLElBQUksQ0FBQztnQkFBRUcsU0FBUztZQUFpRCxHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDeEc7UUFFQSxnQ0FBZ0M7UUFDaEMsTUFBTVEsZUFBZSxNQUFNbEIsOENBQUtBLENBQzlCLENBQUM7Ozs4QkFHdUIsQ0FBQyxFQUN6QjtZQUFDYSxLQUFLTSxFQUFFO1NBQUM7UUFHWCxNQUFNQyxRQUFRRixhQUFhRyxHQUFHLENBQUNDLENBQUFBLE9BQVFBLEtBQUtDLFVBQVU7UUFFdEQsb0RBQW9EO1FBQ3BELE1BQU1DLFlBQVlDLFFBQVFDLEdBQUcsQ0FBQ0MsVUFBVTtRQUN4QyxJQUFJLENBQUNILFdBQVc7WUFDZEksUUFBUUMsS0FBSyxDQUFDO1lBQ2QsT0FBTzlCLHFEQUFZQSxDQUFDTyxJQUFJLENBQUM7Z0JBQUVHLFNBQVM7WUFBdUMsR0FBRztnQkFBRUMsUUFBUTtZQUFJO1FBQzlGO1FBRUEsTUFBTW9CLGVBQWU7WUFDbkJDLFFBQVFsQixLQUFLTSxFQUFFO1lBQ2ZaLE9BQU9NLEtBQUtOLEtBQUs7WUFDakJ5QixRQUFRbkIsS0FBS21CLE1BQU07WUFDbkJaLE9BQU9BO1FBQ1Q7UUFFQSxNQUFNYSxRQUFRL0Isd0RBQVEsQ0FBQzRCLGNBQWNOLFdBQVc7WUFDOUNXLFdBQVc7UUFDYjtRQUVBLE1BQU1DLFdBQVdyQyxxREFBWUEsQ0FBQ08sSUFBSSxDQUFDO1lBQ2pDRyxTQUFTO1lBQ1RJLE1BQU07Z0JBQ0pNLElBQUlOLEtBQUtNLEVBQUU7Z0JBQ1haLE9BQU9NLEtBQUtOLEtBQUs7Z0JBQ2pCeUIsUUFBUW5CLEtBQUttQixNQUFNO2dCQUNuQlosT0FBT0E7WUFDVDtZQUNBYTtRQUNGLEdBQUc7WUFBRXZCLFFBQVE7UUFBSTtRQUVqQixPQUFPMEI7SUFFVCxFQUFFLE9BQU9QLE9BQU87UUFDZCxNQUFNUSxhQUFhUjtRQUNuQkQsUUFBUUMsS0FBSyxDQUFDLDZCQUE2QlE7UUFDM0MsT0FBT3RDLHFEQUFZQSxDQUFDTyxJQUFJLENBQUM7WUFBRUcsU0FBUztZQUErQjZCLGNBQWNELFdBQVc1QixPQUFPO1FBQUMsR0FBRztZQUFFQyxRQUFRO1FBQUk7SUFDdkg7QUFDRiIsInNvdXJjZXMiOlsiRDpcXENvbnN0ZWxsYXRpb25zXFxMZW9cXEVSWVByb2plY3RcXGVyeS1hcHBcXHNyY1xcYXBwXFxhcGlcXGF1dGhcXGxvZ2luXFxyb3V0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvYXBwL2FwaS9hdXRoL2xvZ2luL3JvdXRlLnRzXHJcbmltcG9ydCB7IE5leHRSZXF1ZXN0LCBOZXh0UmVzcG9uc2UgfSBmcm9tICduZXh0L3NlcnZlcic7XHJcbmltcG9ydCB7IHF1ZXJ5IH0gZnJvbSAnQC9saWIvZGInO1xyXG5pbXBvcnQgYmNyeXB0IGZyb20gJ2JjcnlwdGpzJztcclxuaW1wb3J0IGp3dCBmcm9tICdqc29ud2VidG9rZW4nO1xyXG5pbXBvcnQgeyBSb3dEYXRhUGFja2V0IH0gZnJvbSAnbXlzcWwyJztcclxuXHJcbi8vIEludGVyZmF6IHBhcmEgZWwgY3VlcnBvIGRlIGxhIHNvbGljaXR1ZCBkZSBsb2dpblxyXG5pbnRlcmZhY2UgTG9naW5SZXF1ZXN0Qm9keSB7XHJcbiAgZW1haWw6IHN0cmluZztcclxuICBwYXNzd29yZDogc3RyaW5nO1xyXG59XHJcblxyXG4vLyBJbnRlcmZheiBwYXJhIGxvcyBkYXRvcyBkZWwgdXN1YXJpbyBxdWUgcmVjdXBlcmFtb3MgZGUgbGEgQkRcclxuaW50ZXJmYWNlIFVzZXJGcm9tREIgZXh0ZW5kcyBSb3dEYXRhUGFja2V0IHtcclxuICBpZDogbnVtYmVyO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbiAgcGFzc3dvcmRfaGFzaDogc3RyaW5nO1xyXG4gIG5vbWJyZTogc3RyaW5nO1xyXG4gIGFjdGl2bzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gSW50ZXJmYXogcGFyYSBsb3Mgcm9sZXMgcmVjdXBlcmFkb3MgZGUgbGEgQkRcclxuaW50ZXJmYWNlIFVzZXJSb2xlIGV4dGVuZHMgUm93RGF0YVBhY2tldCB7XHJcbiAgbm9tYnJlX3JvbDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gUE9TVChyZXF1ZXN0OiBOZXh0UmVxdWVzdCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxdWVzdC5qc29uKCkgYXMgTG9naW5SZXF1ZXN0Qm9keTtcclxuICAgIGNvbnN0IHsgZW1haWwsIHBhc3N3b3JkIH0gPSBib2R5O1xyXG5cclxuICAgIGlmICghZW1haWwgfHwgIXBhc3N3b3JkKSB7XHJcbiAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG1lc3NhZ2U6ICdFbWFpbCB5IGNvbnRyYXNlw7FhIHNvbiByZXF1ZXJpZG9zLicgfSwgeyBzdGF0dXM6IDQwMCB9KTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB1c2VyUmVzdWx0cyA9IGF3YWl0IHF1ZXJ5PFVzZXJGcm9tREJbXT4oXHJcbiAgICAgICdTRUxFQ1QgaWQsIGVtYWlsLCBub21icmUsIHBhc3N3b3JkX2hhc2gsIGFjdGl2byBGUk9NIHVzdWFyaW9zIFdIRVJFIGVtYWlsID0gPycsXHJcbiAgICAgIFtlbWFpbF1cclxuICAgICk7XHJcblxyXG4gICAgaWYgKHVzZXJSZXN1bHRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBtZXNzYWdlOiAnQ3JlZGVuY2lhbGVzIGludsOhbGlkYXMuIFVzdWFyaW8gbm8gZW5jb250cmFkby4nIH0sIHsgc3RhdHVzOiA0MDEgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdXNlciA9IHVzZXJSZXN1bHRzWzBdO1xyXG5cclxuICAgIGlmICghdXNlci5hY3Rpdm8pIHtcclxuICAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBtZXNzYWdlOiAnRXN0YSBjdWVudGEgaGEgc2lkbyBkZXNhY3RpdmFkYS4nIH0sIHsgc3RhdHVzOiA0MDMgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaXNQYXNzd29yZE1hdGNoID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUocGFzc3dvcmQsIHVzZXIucGFzc3dvcmRfaGFzaCk7XHJcblxyXG4gICAgaWYgKCFpc1Bhc3N3b3JkTWF0Y2gpIHtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogJ0NyZWRlbmNpYWxlcyBpbnbDoWxpZGFzLiBDb250cmFzZcOxYSBpbmNvcnJlY3RhLicgfSwgeyBzdGF0dXM6IDQwMSB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBPYnRlbmVyIGxvcyByb2xlcyBkZWwgdXN1YXJpb1xyXG4gICAgY29uc3Qgcm9sZXNSZXN1bHRzID0gYXdhaXQgcXVlcnk8VXNlclJvbGVbXT4oXHJcbiAgICAgIGBTRUxFQ1Qgci5ub21icmVfcm9sXHJcbiAgICAgICBGUk9NIHJvbGVzIHJcclxuICAgICAgIEpPSU4gdXN1YXJpb19yb2xlcyB1ciBPTiByLmlkID0gdXIucm9sX2lkXHJcbiAgICAgICBXSEVSRSB1ci51c3VhcmlvX2lkID0gP2AsXHJcbiAgICAgIFt1c2VyLmlkXVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCByb2xlcyA9IHJvbGVzUmVzdWx0cy5tYXAocm9sZSA9PiByb2xlLm5vbWJyZV9yb2wpO1xyXG5cclxuICAgIC8vIFNpIGxhcyBjcmVkZW5jaWFsZXMgc29uIGNvcnJlY3RhcywgZ2VuZXJhciB1biBKV1RcclxuICAgIGNvbnN0IGp3dFNlY3JldCA9IHByb2Nlc3MuZW52LkpXVF9TRUNSRVQ7XHJcbiAgICBpZiAoIWp3dFNlY3JldCkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdKV1RfU0VDUkVUIG5vIGVzdMOhIGRlZmluaWRvIGVuIGxhcyB2YXJpYWJsZXMgZGUgZW50b3Juby4nKTtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogJ0Vycm9yIGRlIGNvbmZpZ3VyYWNpw7NuIGRlbCBzZXJ2aWRvci4nIH0sIHsgc3RhdHVzOiA1MDAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdG9rZW5QYXlsb2FkID0ge1xyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxyXG4gICAgICBub21icmU6IHVzZXIubm9tYnJlLFxyXG4gICAgICByb2xlczogcm9sZXMsIC8vIEluY2x1aXIgbG9zIHJvbGVzIGVuIGVsIHBheWxvYWQgZGVsIHRva2VuXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHRva2VuID0gand0LnNpZ24odG9rZW5QYXlsb2FkLCBqd3RTZWNyZXQsIHtcclxuICAgICAgZXhwaXJlc0luOiAnMWgnLCAvLyBQb3IgZWplbXBsbywgMSBob3JhXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZXNwb25zZSA9IE5leHRSZXNwb25zZS5qc29uKHtcclxuICAgICAgbWVzc2FnZTogJ0luaWNpbyBkZSBzZXNpw7NuIGV4aXRvc28uJyxcclxuICAgICAgdXNlcjoge1xyXG4gICAgICAgIGlkOiB1c2VyLmlkLFxyXG4gICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxyXG4gICAgICAgIG5vbWJyZTogdXNlci5ub21icmUsXHJcbiAgICAgICAgcm9sZXM6IHJvbGVzLCAvLyBUYW1iacOpbiBkZXZvbHZlciBsb3Mgcm9sZXMgZW4gbGEgcmVzcHVlc3RhIGRlbCB1c3VhcmlvIHNpIGVzIMO6dGlsIHBhcmEgZWwgZnJvbnRlbmQgaW5tZWRpYXRhbWVudGVcclxuICAgICAgfSxcclxuICAgICAgdG9rZW4sXHJcbiAgICB9LCB7IHN0YXR1czogMjAwIH0pO1xyXG5cclxuICAgIHJldHVybiByZXNwb25zZTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnN0IHR5cGVkRXJyb3IgPSBlcnJvciBhcyB7IG1lc3NhZ2U/OiBzdHJpbmc7IGNvZGU/OiBzdHJpbmc7IHNxbFN0YXRlPzogc3RyaW5nIH07XHJcbiAgICBjb25zb2xlLmVycm9yKCdFcnJvciBlbiAvYXBpL2F1dGgvbG9naW46JywgdHlwZWRFcnJvcik7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBtZXNzYWdlOiAnRXJyb3IgaW50ZXJubyBkZWwgc2Vydmlkb3IuJywgZXJyb3JEZXRhaWxzOiB0eXBlZEVycm9yLm1lc3NhZ2UgfSwgeyBzdGF0dXM6IDUwMCB9KTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsInF1ZXJ5IiwiYmNyeXB0Iiwiand0IiwiUE9TVCIsInJlcXVlc3QiLCJib2R5IiwianNvbiIsImVtYWlsIiwicGFzc3dvcmQiLCJtZXNzYWdlIiwic3RhdHVzIiwidXNlclJlc3VsdHMiLCJsZW5ndGgiLCJ1c2VyIiwiYWN0aXZvIiwiaXNQYXNzd29yZE1hdGNoIiwiY29tcGFyZSIsInBhc3N3b3JkX2hhc2giLCJyb2xlc1Jlc3VsdHMiLCJpZCIsInJvbGVzIiwibWFwIiwicm9sZSIsIm5vbWJyZV9yb2wiLCJqd3RTZWNyZXQiLCJwcm9jZXNzIiwiZW52IiwiSldUX1NFQ1JFVCIsImNvbnNvbGUiLCJlcnJvciIsInRva2VuUGF5bG9hZCIsInVzZXJJZCIsIm5vbWJyZSIsInRva2VuIiwic2lnbiIsImV4cGlyZXNJbiIsInJlc3BvbnNlIiwidHlwZWRFcnJvciIsImVycm9yRGV0YWlscyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/auth/login/route.ts\n");

/***/ }),

/***/ "(rsc)/./src/lib/db.ts":
/*!***********************!*\
  !*** ./src/lib/db.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   query: () => (/* binding */ query)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n// src/lib/db.ts\n\n// Configura los detalles de la conexión usando variables de entorno\nconst dbConfig = {\n    host: process.env.DB_HOST,\n    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306,\n    user: process.env.DB_USER,\n    password: process.env.DB_PASSWORD,\n    database: process.env.DB_NAME,\n    waitForConnections: true,\n    connectionLimit: 10,\n    queueLimit: 0\n};\n// El pool se crea una sola vez y se reutiliza\nlet pool;\nfunction getPool() {\n    if (!pool) {\n        try {\n            pool = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool(dbConfig);\n            console.log('MySQL Connection Pool created successfully.');\n        // Nota: mysql2/promise Pool no soporta el evento 'error' directamente en el pool object como en `mysql`.\n        // Los errores de conexión individuales se manejan en los catch de las consultas.\n        } catch (error) {\n            console.error('Failed to create MySQL Connection Pool:', error);\n            throw error;\n        }\n    }\n    return pool;\n}\n// Hacemos la función query más genérica con tipos\nasync function query(sql, // Corregido: params puede ser un array de primitivas o un objeto para sentencias preparadas\nparams) {\n    const currentPool = getPool();\n    // Corregido: La variable 'connection' no se usaba y ha sido eliminada.\n    try {\n        const [results] = await currentPool.execute(sql, params);\n        return results;\n    } catch (error) {\n        // Para el log, podemos acceder a 'message' y 'code' si asumimos que es un error de MySQL o similar.\n        // Para mayor seguridad, se podría hacer una verificación de tipo: if (error instanceof Error)\n        const typedError = error;\n        console.error('Error executing query:', {\n            sql,\n            params,\n            errorMessage: typedError.message,\n            errorCode: typedError.code,\n            sqlState: typedError.sqlState\n        });\n        throw new Error(`Database query failed. SQLState: ${typedError.sqlState}, Code: ${typedError.code}`);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvbGliL2RiLnRzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsZ0JBQWdCO0FBQ3VFO0FBZXZGLG9FQUFvRTtBQUNwRSxNQUFNQyxXQUFxQjtJQUN6QkMsTUFBTUMsUUFBUUMsR0FBRyxDQUFDQyxPQUFPO0lBQ3pCQyxNQUFNSCxRQUFRQyxHQUFHLENBQUNHLE9BQU8sR0FBR0MsU0FBU0wsUUFBUUMsR0FBRyxDQUFDRyxPQUFPLEVBQUUsTUFBTTtJQUNoRUUsTUFBTU4sUUFBUUMsR0FBRyxDQUFDTSxPQUFPO0lBQ3pCQyxVQUFVUixRQUFRQyxHQUFHLENBQUNRLFdBQVc7SUFDakNDLFVBQVVWLFFBQVFDLEdBQUcsQ0FBQ1UsT0FBTztJQUM3QkMsb0JBQW9CO0lBQ3BCQyxpQkFBaUI7SUFDakJDLFlBQVk7QUFDZDtBQUVBLDhDQUE4QztBQUM5QyxJQUFJQztBQUVKLFNBQVNDO0lBQ1AsSUFBSSxDQUFDRCxNQUFNO1FBQ1QsSUFBSTtZQUNGQSxPQUFPbEIsc0RBQWdCLENBQUNDO1lBQ3hCb0IsUUFBUUMsR0FBRyxDQUFDO1FBRVoseUdBQXlHO1FBQ3pHLGlGQUFpRjtRQUNuRixFQUFFLE9BQU9DLE9BQU87WUFDZEYsUUFBUUUsS0FBSyxDQUFDLDJDQUEyQ0E7WUFDekQsTUFBTUE7UUFDUjtJQUNGO0lBQ0EsT0FBT0w7QUFDVDtBQUVBLGtEQUFrRDtBQUMzQyxlQUFlTSxNQUNwQkMsR0FBVyxFQUNYLDRGQUE0RjtBQUM1RkMsTUFBbUY7SUFFbkYsTUFBTUMsY0FBY1I7SUFDcEIsdUVBQXVFO0lBQ3ZFLElBQUk7UUFDRixNQUFNLENBQUNTLFFBQVEsR0FBRyxNQUFNRCxZQUFZRSxPQUFPLENBQUlKLEtBQUtDO1FBQ3BELE9BQU9FO0lBQ1QsRUFBRSxPQUFPTCxPQUFPO1FBQ2Qsb0dBQW9HO1FBQ3BHLDhGQUE4RjtRQUM5RixNQUFNTyxhQUFhUDtRQUNuQkYsUUFBUUUsS0FBSyxDQUFDLDBCQUEwQjtZQUNwQ0U7WUFDQUM7WUFDQUssY0FBY0QsV0FBV0UsT0FBTztZQUNoQ0MsV0FBV0gsV0FBV0ksSUFBSTtZQUMxQkMsVUFBVUwsV0FBV0ssUUFBUTtRQUNqQztRQUNBLE1BQU0sSUFBSUMsTUFBTSxDQUFDLGlDQUFpQyxFQUFFTixXQUFXSyxRQUFRLENBQUMsUUFBUSxFQUFFTCxXQUFXSSxJQUFJLEVBQUU7SUFDckc7QUFDRiIsInNvdXJjZXMiOlsiRDpcXENvbnN0ZWxsYXRpb25zXFxMZW9cXEVSWVByb2plY3RcXGVyeS1hcHBcXHNyY1xcbGliXFxkYi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvbGliL2RiLnRzXHJcbmltcG9ydCBteXNxbCwgeyBQb29sLCBSb3dEYXRhUGFja2V0LCBPa1BhY2tldCwgUmVzdWx0U2V0SGVhZGVyIH0gZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuLy8gRGVmaW5pbW9zIHVuYSBpbnRlcmZheiBwYXJhIGxhIGNvbmZpZ3VyYWNpw7NuIGRlIGxhIEJEIHBhcmEgbWF5b3IgY2xhcmlkYWRcclxuaW50ZXJmYWNlIERiQ29uZmlnIHtcclxuICBob3N0Pzogc3RyaW5nO1xyXG4gIHBvcnQ/OiBudW1iZXI7XHJcbiAgdXNlcj86IHN0cmluZztcclxuICBwYXNzd29yZD86IHN0cmluZztcclxuICBkYXRhYmFzZT86IHN0cmluZztcclxuICAvLyBPcGNpb25lcyBhZGljaW9uYWxlcyBwYXJhIGVsIHBvb2wgc2kgbGFzIG5lY2VzaXRhc1xyXG4gIHdhaXRGb3JDb25uZWN0aW9ucz86IGJvb2xlYW47XHJcbiAgY29ubmVjdGlvbkxpbWl0PzogbnVtYmVyO1xyXG4gIHF1ZXVlTGltaXQ/OiBudW1iZXI7XHJcbn1cclxuXHJcbi8vIENvbmZpZ3VyYSBsb3MgZGV0YWxsZXMgZGUgbGEgY29uZXhpw7NuIHVzYW5kbyB2YXJpYWJsZXMgZGUgZW50b3Jub1xyXG5jb25zdCBkYkNvbmZpZzogRGJDb25maWcgPSB7XHJcbiAgaG9zdDogcHJvY2Vzcy5lbnYuREJfSE9TVCxcclxuICBwb3J0OiBwcm9jZXNzLmVudi5EQl9QT1JUID8gcGFyc2VJbnQocHJvY2Vzcy5lbnYuREJfUE9SVCwgMTApIDogMzMwNixcclxuICB1c2VyOiBwcm9jZXNzLmVudi5EQl9VU0VSLFxyXG4gIHBhc3N3b3JkOiBwcm9jZXNzLmVudi5EQl9QQVNTV09SRCxcclxuICBkYXRhYmFzZTogcHJvY2Vzcy5lbnYuREJfTkFNRSxcclxuICB3YWl0Rm9yQ29ubmVjdGlvbnM6IHRydWUsXHJcbiAgY29ubmVjdGlvbkxpbWl0OiAxMCwgLy8gUHVlZGVzIGFqdXN0YXIgZXN0ZSB2YWxvciBzZWfDum4gdHVzIG5lY2VzaWRhZGVzXHJcbiAgcXVldWVMaW1pdDogMFxyXG59O1xyXG5cclxuLy8gRWwgcG9vbCBzZSBjcmVhIHVuYSBzb2xhIHZleiB5IHNlIHJldXRpbGl6YVxyXG5sZXQgcG9vbDogUG9vbCB8IHVuZGVmaW5lZDtcclxuXHJcbmZ1bmN0aW9uIGdldFBvb2woKTogUG9vbCB7XHJcbiAgaWYgKCFwb29sKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBwb29sID0gbXlzcWwuY3JlYXRlUG9vbChkYkNvbmZpZyk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdNeVNRTCBDb25uZWN0aW9uIFBvb2wgY3JlYXRlZCBzdWNjZXNzZnVsbHkuJyk7XHJcblxyXG4gICAgICAvLyBOb3RhOiBteXNxbDIvcHJvbWlzZSBQb29sIG5vIHNvcG9ydGEgZWwgZXZlbnRvICdlcnJvcicgZGlyZWN0YW1lbnRlIGVuIGVsIHBvb2wgb2JqZWN0IGNvbW8gZW4gYG15c3FsYC5cclxuICAgICAgLy8gTG9zIGVycm9yZXMgZGUgY29uZXhpw7NuIGluZGl2aWR1YWxlcyBzZSBtYW5lamFuIGVuIGxvcyBjYXRjaCBkZSBsYXMgY29uc3VsdGFzLlxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGNyZWF0ZSBNeVNRTCBDb25uZWN0aW9uIFBvb2w6JywgZXJyb3IpO1xyXG4gICAgICB0aHJvdyBlcnJvcjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHBvb2w7XHJcbn1cclxuXHJcbi8vIEhhY2Vtb3MgbGEgZnVuY2nDs24gcXVlcnkgbcOhcyBnZW7DqXJpY2EgY29uIHRpcG9zXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWVyeTxUIGV4dGVuZHMgUm93RGF0YVBhY2tldFtdIHwgUm93RGF0YVBhY2tldFtdW10gfCBPa1BhY2tldCB8IE9rUGFja2V0W10gfCBSZXN1bHRTZXRIZWFkZXI+KFxyXG4gIHNxbDogc3RyaW5nLFxyXG4gIC8vIENvcnJlZ2lkbzogcGFyYW1zIHB1ZWRlIHNlciB1biBhcnJheSBkZSBwcmltaXRpdmFzIG8gdW4gb2JqZXRvIHBhcmEgc2VudGVuY2lhcyBwcmVwYXJhZGFzXHJcbiAgcGFyYW1zPzogKHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBudWxsKVtdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCB1bmRlZmluZWRcclxuKTogUHJvbWlzZTxUPiB7XHJcbiAgY29uc3QgY3VycmVudFBvb2wgPSBnZXRQb29sKCk7XHJcbiAgLy8gQ29ycmVnaWRvOiBMYSB2YXJpYWJsZSAnY29ubmVjdGlvbicgbm8gc2UgdXNhYmEgeSBoYSBzaWRvIGVsaW1pbmFkYS5cclxuICB0cnkge1xyXG4gICAgY29uc3QgW3Jlc3VsdHNdID0gYXdhaXQgY3VycmVudFBvb2wuZXhlY3V0ZTxUPihzcWwsIHBhcmFtcyk7XHJcbiAgICByZXR1cm4gcmVzdWx0cztcclxuICB9IGNhdGNoIChlcnJvcikgeyAvLyBDb3JyZWdpZG86IFVzYXIgJ3Vua25vd24nIHBhcmEgZWwgdGlwbyBkZSBlcnJvciB5IGx1ZWdvIHZlcmlmaWNhcmxvIHNpIGVzIG5lY2VzYXJpb1xyXG4gICAgLy8gUGFyYSBlbCBsb2csIHBvZGVtb3MgYWNjZWRlciBhICdtZXNzYWdlJyB5ICdjb2RlJyBzaSBhc3VtaW1vcyBxdWUgZXMgdW4gZXJyb3IgZGUgTXlTUUwgbyBzaW1pbGFyLlxyXG4gICAgLy8gUGFyYSBtYXlvciBzZWd1cmlkYWQsIHNlIHBvZHLDrWEgaGFjZXIgdW5hIHZlcmlmaWNhY2nDs24gZGUgdGlwbzogaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpXHJcbiAgICBjb25zdCB0eXBlZEVycm9yID0gZXJyb3IgYXMgeyBtZXNzYWdlPzogc3RyaW5nOyBjb2RlPzogc3RyaW5nOyBzcWxTdGF0ZT86IHN0cmluZyB9O1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgZXhlY3V0aW5nIHF1ZXJ5OicsIHtcclxuICAgICAgICBzcWwsXHJcbiAgICAgICAgcGFyYW1zLFxyXG4gICAgICAgIGVycm9yTWVzc2FnZTogdHlwZWRFcnJvci5tZXNzYWdlLFxyXG4gICAgICAgIGVycm9yQ29kZTogdHlwZWRFcnJvci5jb2RlLFxyXG4gICAgICAgIHNxbFN0YXRlOiB0eXBlZEVycm9yLnNxbFN0YXRlXHJcbiAgICB9KTtcclxuICAgIHRocm93IG5ldyBFcnJvcihgRGF0YWJhc2UgcXVlcnkgZmFpbGVkLiBTUUxTdGF0ZTogJHt0eXBlZEVycm9yLnNxbFN0YXRlfSwgQ29kZTogJHt0eXBlZEVycm9yLmNvZGV9YCk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJteXNxbCIsImRiQ29uZmlnIiwiaG9zdCIsInByb2Nlc3MiLCJlbnYiLCJEQl9IT1NUIiwicG9ydCIsIkRCX1BPUlQiLCJwYXJzZUludCIsInVzZXIiLCJEQl9VU0VSIiwicGFzc3dvcmQiLCJEQl9QQVNTV09SRCIsImRhdGFiYXNlIiwiREJfTkFNRSIsIndhaXRGb3JDb25uZWN0aW9ucyIsImNvbm5lY3Rpb25MaW1pdCIsInF1ZXVlTGltaXQiLCJwb29sIiwiZ2V0UG9vbCIsImNyZWF0ZVBvb2wiLCJjb25zb2xlIiwibG9nIiwiZXJyb3IiLCJxdWVyeSIsInNxbCIsInBhcmFtcyIsImN1cnJlbnRQb29sIiwicmVzdWx0cyIsImV4ZWN1dGUiLCJ0eXBlZEVycm9yIiwiZXJyb3JNZXNzYWdlIiwibWVzc2FnZSIsImVycm9yQ29kZSIsImNvZGUiLCJzcWxTdGF0ZSIsIkVycm9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/lib/db.ts\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mysql2","vendor-chunks/aws-ssl-profiles","vendor-chunks/iconv-lite","vendor-chunks/semver","vendor-chunks/long","vendor-chunks/lru-cache","vendor-chunks/jsonwebtoken","vendor-chunks/lodash.includes","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/lru.min","vendor-chunks/jws","vendor-chunks/lodash.once","vendor-chunks/jwa","vendor-chunks/lodash.isinteger","vendor-chunks/sqlstring","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/seq-queue","vendor-chunks/named-placeholders","vendor-chunks/lodash.isplainobject","vendor-chunks/generate-function","vendor-chunks/ms","vendor-chunks/lodash.isstring","vendor-chunks/safer-buffer","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isboolean","vendor-chunks/safe-buffer","vendor-chunks/buffer-equal-constant-time","vendor-chunks/bcryptjs"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fauth%2Flogin%2Froute&page=%2Fapi%2Fauth%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2Flogin%2Froute.ts&appDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CConstellations%5CLeo%5CERYProject%5Cery-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();